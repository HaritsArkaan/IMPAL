package com.snackhunt.snackhunt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnackhuntApplicationTests {

	@Test
	void contextLoads() {
	}

}
